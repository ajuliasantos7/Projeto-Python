import os
import pandas as pd
from fpdf import FPDF
import matplotlib.pyplot as plt

# -------------- PDF ----------------
class PDF(FPDF):
    def header(self):
        self.image('kick.png', 150, 10, 33)
        self.set_font('Arial', 'B', 15)
        self.cell(80)
        self.cell(
            30, 10, 'PROJETO PYTHON', 0, 0, 'C')
        self.ln(10)
        self.line(75, 20, 135, 20)

    def footer(self):
        self.set_y(-15)
        self.set_font('Arial', 'I', 8)
        self.cell(0, 20, 'Page ' + str(self.page_no()) + '/{nb}', 0, 0, 'C')


pdf = PDF()
pdf.add_page()
texto_1 = "Covid-19"
pdf.image(name= 'Coronavírus.jpg', x=83, y=140, w=90)
pdf.cell(w=0, h=120, txt=texto_1, align='C')
pdf.set_font('Times', '', 17)

# ----------- Text -------------
pdf.add_page()
pdf.set_font('Times', '', 15)
pdf.set_margins(20, 40, 0)
texto = 'COVID-19 é uma doença causada por um vírus da família dos coronavírus. Registros da doença iniciaram-se no ano de 2019, mas a identificação do agente causador e as consequências dessa infecção só ocorreram no ano de 2020.
Responsável por causar febre, dificuldade respiratória e tosse, essa infecção assemelha-se a uma gripe. Entretanto, a COVID-19 pode levar a complicações sérias e até mesmo à morte, devendo ser, portanto, encarada como um grave problema de saúde pública. A transmissão da COVID-19 ocorre de uma pessoa para outra por meio do contato com gotículas respiratórias. Assim sendo, uma das medidas para se prevenir é evitar locais com aglomerações de pessoas'

pdf.multi_cell(w=165, h=8, txt=texto, align=' C')

pdf.output('Covid-SP.pdf', 'F')

os.system("pause")